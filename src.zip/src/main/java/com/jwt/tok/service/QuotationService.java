package com.jwt.tok.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jwt.tok.model.Enquiry;
import com.jwt.tok.model.QuotationItem;
import com.jwt.tok.model.QuotationMaster;
import com.jwt.tok.repository.EnquiryRepository;
import com.jwt.tok.repository.QuotationRepository;

@Service
public class QuotationService {
	@Autowired
	private EnquiryRepository enquiryRepository;

	private final QuotationRepository quotationRepository;

	public QuotationService(QuotationRepository quotationRepository) {
		this.quotationRepository = quotationRepository;
	}

//	public QuotationMaster saveQuotation(QuotationMaster quotation) {
//
//		double totalAmount = 0;
//		double totalTax = 0;
//		double grandTotal = 0;
//
//		for (QuotationItem item : quotation.getItems()) {
//
//			double qty = item.getQuantity();
//			double price = item.getUnitPrice();
//
//			double discountPercent = item.getDiscount() == null ? 0 : item.getDiscount();
//
//			double tax = item.getTaxPercent() == null ? 0 : item.getTaxPercent();
//
//			double total = qty * price;
//
//			double discountAmount = (total * discountPercent) / 100;
//			double afterDisc = Math.max(total - discountAmount, 0);
//
//			double taxAmt = (afterDisc * tax) / 100;
//			double rowTotal = afterDisc + taxAmt;
//
//			item.setTotalPrice(total);
//			item.setTotalAfterDisc(afterDisc);
//			item.setTaxAmount(taxAmt);
//			item.setGrandTotal(rowTotal);
//
//			item.setQuotation(quotation);
//
//			totalAmount += afterDisc;
//			totalTax += taxAmt;
//			grandTotal += rowTotal;
//		}
//
//		quotation.setTotalAmount(totalAmount);
//		quotation.setTotalTax(totalTax);
//		quotation.setGrandTotal(grandTotal);
//
//		return quotationRepository.save(quotation);
//	}
	public QuotationMaster saveQuotation(QuotationMaster quotation) {

	    // ✅ 1. Enquiry fetch कर
	    Long enquiryId = quotation.getEnquiryId();

	    Enquiry enquiry = enquiryRepository.findById(enquiryId)
	            .orElseThrow(() -> new RuntimeException("Enquiry not found"));

	    // ❌ 2. DOUBLE QUOTATION BLOCK
	    if (Boolean.TRUE.equals(enquiry.getQuotationCreated())) {
	        throw new RuntimeException("Quotation already created for this enquiry");
	    }

	    // ================= EXISTING CALCULATION LOGIC =================

	    double totalAmount = 0;
	    double totalTax = 0;
	    double grandTotal = 0;

	    for (QuotationItem item : quotation.getItems()) {

	        double qty = item.getQuantity();
	        double price = item.getUnitPrice();

	        double discountPercent = item.getDiscount() == null ? 0 : item.getDiscount();
	        double tax = item.getTaxPercent() == null ? 0 : item.getTaxPercent();

	        double total = qty * price;

	        double discountAmount = (total * discountPercent) / 100;
	        double afterDisc = Math.max(total - discountAmount, 0);

	        double taxAmt = (afterDisc * tax) / 100;
	        double rowTotal = afterDisc + taxAmt;

	        item.setTotalPrice(total);
	        item.setTotalAfterDisc(afterDisc);
	        item.setTaxAmount(taxAmt);
	        item.setGrandTotal(rowTotal);

	        item.setQuotation(quotation);

	        totalAmount += afterDisc;
	        totalTax += taxAmt;
	        grandTotal += rowTotal;
	    }

	    quotation.setTotalAmount(totalAmount);
	    quotation.setTotalTax(totalTax);
	    quotation.setGrandTotal(grandTotal);

	    // ✅ 3. Quotation save
	    QuotationMaster savedQuotation = quotationRepository.save(quotation);

	    // ✅ 4. Enquiry update (VERY IMPORTANT)
	    enquiry.setQuotationCreated(true);
	    enquiryRepository.save(enquiry);

	    return savedQuotation;
	}

//	public List<QuotationMaster> getAllQuotations() {
//		return quotationRepository.findAll();
//	}
	public List<QuotationMaster> getAllQuotations(String role, String dealerCode) {

		if ("Admin".equals(role)) {
			return quotationRepository.findAll(); // 🔥 Admin → ALL
		}

		// 🔥 Dealer → ONLY OWN
		return quotationRepository.findByDealerCode(dealerCode);
	}

	public QuotationMaster getQuotationById(Long id) {
		return quotationRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Quotation not found with id: " + id));
	}

	public void deleteQuotation(Long id) {

		if (!quotationRepository.existsById(id)) {
			throw new RuntimeException("Quotation not found with id: " + id);
		}

		quotationRepository.deleteById(id);
	}

//	public QuotationMaster updateQuotation(Long id, QuotationMaster updatedQuotation) {
//
//		QuotationMaster existing = quotationRepository.findById(id)
//				.orElseThrow(() -> new RuntimeException("Quotation not found with id: " + id));
//
//		// Update master fields
//		existing.setCustomerName(updatedQuotation.getCustomerName());
//		existing.setContactNo(updatedQuotation.getContactNo());
//		existing.setEmail(updatedQuotation.getEmail());
//		existing.setAddress(updatedQuotation.getAddress());
//		existing.setPartyName(updatedQuotation.getPartyName());
//		existing.setCity(updatedQuotation.getCity());
//		existing.setProduct(updatedQuotation.getProduct());
//		existing.setQuotationDate(updatedQuotation.getQuotationDate());
//		existing.setEnquiryId(updatedQuotation.getEnquiryId());
//
//		// Remove old items
//		existing.getItems().clear();
//
//		// Add new items
//		for (QuotationItem item : updatedQuotation.getItems()) {
//			item.setQuotation(existing);
//			existing.getItems().add(item);
//		}
//
//		return saveQuotation(existing);
//	}
	
	public QuotationMaster updateQuotation(Long id, QuotationMaster updatedQuotation) {

	    QuotationMaster existing = quotationRepository.findById(id)
	            .orElseThrow(() -> new RuntimeException("Quotation not found"));

	    // MASTER FIELDS
	    existing.setCustomerName(updatedQuotation.getCustomerName());
	    existing.setContactNo(updatedQuotation.getContactNo());
	    existing.setEmail(updatedQuotation.getEmail());
	    existing.setAddress(updatedQuotation.getAddress());
	    existing.setPartyName(updatedQuotation.getPartyName());
	    existing.setCity(updatedQuotation.getCity());
	    existing.setProduct(updatedQuotation.getProduct());
	    existing.setQuotationDate(updatedQuotation.getQuotationDate());

	    // 🔥 IMPORTANT: enquiryId overwrite करू नको
	    // existing.setEnquiryId(updatedQuotation.getEnquiryId()); ❌ REMOVE

	    // ITEMS RESET
	    existing.getItems().clear();

	    for (QuotationItem item : updatedQuotation.getItems()) {
	        item.setQuotation(existing);
	        existing.getItems().add(item);
	    }

	    // ✅ ONLY CALCULATION
	    calculateTotals(existing);

	    return quotationRepository.save(existing);
	}

//-------------------------------------------------------
	private void calculateTotals(QuotationMaster quotation) {

	    double totalAmount = 0;
	    double totalTax = 0;
	    double grandTotal = 0;

	    for (QuotationItem item : quotation.getItems()) {

	        double qty = item.getQuantity();
	        double price = item.getUnitPrice();

	        double discountPercent = item.getDiscount() == null ? 0 : item.getDiscount();
	        double tax = item.getTaxPercent() == null ? 0 : item.getTaxPercent();

	        double total = qty * price;

	        double discountAmount = (total * discountPercent) / 100;
	        double afterDisc = Math.max(total - discountAmount, 0);

	        double taxAmt = (afterDisc * tax) / 100;
	        double rowTotal = afterDisc + taxAmt;

	        item.setTotalPrice(total);
	        item.setTotalAfterDisc(afterDisc);
	        item.setTaxAmount(taxAmt);
	        item.setGrandTotal(rowTotal);

	        item.setQuotation(quotation);

	        totalAmount += afterDisc;
	        totalTax += taxAmt;
	        grandTotal += rowTotal;
	    }

	    quotation.setTotalAmount(totalAmount);
	    quotation.setTotalTax(totalTax);
	    quotation.setGrandTotal(grandTotal);
	}

	//------------------------------------------------
}
