package com.jwt.tok.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jwt.tok.model.QuotationMaster;
import com.jwt.tok.response.ApiResponse;
import com.jwt.tok.service.QuotationService;
import com.jwt.tok.util.JwtUtil;

@RestController
@RequestMapping("/api/quotation")
@CrossOrigin("*")
public class QuotationController {

	@Autowired
	private JwtUtil jwtUtil;
	private final QuotationService quotationService;

	public QuotationController(QuotationService quotationService) {
		this.quotationService = quotationService;
	}

//    @PostMapping("/save")
//    public ResponseEntity<ApiResponse<QuotationMaster>> save(
//            @RequestBody QuotationMaster quotation
//    ) {
//        return ResponseEntity.ok(
//            ApiResponse.success(
//                "Quotation saved successfully",
//                quotationService.saveQuotation(quotation)
//            )
//        );
//    }
	@PostMapping("/save")
	@PreAuthorize("hasAnyRole('Admin','Dealer')")
	public ResponseEntity<ApiResponse<QuotationMaster>> save(@RequestBody QuotationMaster quotation,
			HttpServletRequest request) {
		String token = request.getHeader("Authorization").substring(7);
		String role = jwtUtil.extractRole(token);

		if ("Dealer".equals(role)) {
			String dealerCode = jwtUtil.extractDealerCode(token);
			quotation.setDealerCode(dealerCode); // 🔥 AUTO LINK
		}

		return ResponseEntity
				.ok(ApiResponse.success("Quotation saved successfully", quotationService.saveQuotation(quotation)));
	}

//    @GetMapping("/getAll")
//    public ResponseEntity<ApiResponse<List<QuotationMaster>>> getAll() {
//        return ResponseEntity.ok(
//                ApiResponse.success(
//                        "Quotation list fetched successfully",
//                        quotationService.getAllQuotations()
//                )
//        );
//    }
	@GetMapping("/getAll")
	@PreAuthorize("hasAnyRole('Admin','Dealer')")
	public ResponseEntity<ApiResponse<List<QuotationMaster>>> getAll(HttpServletRequest request) {
		String token = request.getHeader("Authorization").substring(7);

		String role = jwtUtil.extractRole(token);
		String dealerCode = jwtUtil.extractDealerCode(token);

		return ResponseEntity.ok(ApiResponse.success("Quotation list fetched successfully",
				quotationService.getAllQuotations(role, dealerCode)));
	}

	@GetMapping("/getById/{id}")
	public ResponseEntity<ApiResponse<QuotationMaster>> getById(@PathVariable Long id) {
		return ResponseEntity
				.ok(ApiResponse.success("Quotation fetched successfully", quotationService.getQuotationById(id)));
	}

	@PutMapping("/update/{id}")
	public ResponseEntity<ApiResponse<QuotationMaster>> update(@PathVariable Long id,
			@RequestBody QuotationMaster quotation) {
		return ResponseEntity.ok(
				ApiResponse.success("Quotation updated successfully", quotationService.updateQuotation(id, quotation)));
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<ApiResponse<String>> delete(@PathVariable Long id) {

		quotationService.deleteQuotation(id);

		return ResponseEntity.ok(ApiResponse.success("Quotation deleted successfully", "Deleted ID: " + id));
	}

}
